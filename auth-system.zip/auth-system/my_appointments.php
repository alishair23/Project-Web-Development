<?php
session_start();
include "db.php";

$user_id = $_SESSION['user_id'];

$p = $conn->query("SELECT id FROM patients WHERE user_id=$user_id")->fetch_assoc();
$patient_id = $p['id'];

$query = "
SELECT a.*, d.doctor_name
FROM appointments a
JOIN doctors d ON a.doctor_id = d.doctor_id
WHERE a.patient_id = $patient_id
ORDER BY a.id DESC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
<title>My Appointments</title>

<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
}

/* BODY */
body{
    font-family:Arial;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    color:#e2e8f0;
    padding:30px;
}

/* TITLE */
h2{
    color:var(--primary);
}

/* CARD */
.app-card{
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(10px);
    padding:15px;
    margin:12px 0;
    border-radius:10px;
    transition:0.3s;
    position:relative;
}

/* TOP BORDER */
.app-card::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:4px;
    background:linear-gradient(90deg,var(--primary),var(--secondary),var(--accent));
}

/* HOVER */
.app-card:hover{
    transform:translateY(-5px);
    box-shadow:0 10px 25px rgba(0,0,0,0.4);
}

/* STATUS */
.status{
    padding:4px 10px;
    border-radius:6px;
    font-size:13px;
    font-weight:bold;
}

/* STATUS COLORS */
.pending{ background:#f59e0b; }
.confirmed{ background:var(--primary); }
.completed{ background:var(--accent); }
.cancelled{ background:#ef4444; }

</style>
</head>

<body>

<h2>My Appointments</h2>

<?php while($row = $result->fetch_assoc()): ?>
<div class="app-card">

    <b>Doctor:</b> <?= $row['doctor_name'] ?><br>
    <b>Date:</b> <?= $row['appointment_date'] ?><br>

    <b>Status:</b> 
    <span class="status <?= $row['status'] ?>">
        <?= ucfirst($row['status']) ?>
    </span>

</div>
<?php endwhile; ?>

</body>
</html>
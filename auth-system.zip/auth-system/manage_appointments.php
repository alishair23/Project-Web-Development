<?php
session_start();
include "db.php";

if($_SESSION['role'] != 'admin'){
    die("Access denied");
}

$result = $conn->query("
    SELECT a.*, p.name 
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    ORDER BY appointment_date DESC
");
?>

<h2>Manage Appointments</h2>

<table border="1">
<tr>
<th>Patient</th>
<th>Doctor</th>
<th>Date</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
<td><?= $row['name'] ?></td>
<td><?= $row['doctor_name'] ?></td>
<td><?= $row['appointment_date'] ?></td>
<td><?= $row['status'] ?></td>
<td>
<a href="update_status.php?id=<?= $row['id'] ?>&status=approved">Approve</a>
<a href="update_status.php?id=<?= $row['id'] ?>&status=rejected">Reject</a>
</td>
</tr>
<?php endwhile; ?>
</table>
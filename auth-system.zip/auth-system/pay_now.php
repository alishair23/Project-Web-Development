<?php
include "db.php";

$id = (int)$_GET['id'];

$stmt = $conn->prepare("
    UPDATE payments 
    SET status='paid' 
    WHERE id=?
");

$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: user_payments.php");
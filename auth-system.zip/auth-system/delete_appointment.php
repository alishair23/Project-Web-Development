<?php
include "db.php";

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM appointments WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: book-appointments.php");

$conn = new mysqli("localhost", "root", "", "auth_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
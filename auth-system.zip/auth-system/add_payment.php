<?php
include "db.php";

$patients = $conn->query("SELECT id,name FROM patients");

if(isset($_POST['submit'])){

    $stmt = $conn->prepare("
        INSERT INTO payments 
        (patient_id, appointment_id, amount, payment_method, status, transaction_id)
        VALUES (?,?,?,?,?,?)
    ");

    $stmt->bind_param(
        "iidsss",
        $_POST['patient_id'],
        $_POST['appointment_id'],
        $_POST['amount'],
        $_POST['payment_method'],
        $_POST['status'],
        $_POST['transaction_id']
    );

    $stmt->execute();

    header("Location: payments.php");
}
?>

<form method="POST">

<select name="patient_id" required>
<option value="">Select Patient</option>
<?php while($p = $patients->fetch_assoc()): ?>
<option value="<?= $p['id'] ?>"><?= $p['name'] ?></option>
<?php endwhile; ?>
</select><br>

<input type="number" step="0.01" name="amount" placeholder="Amount" required><br>

<select name="payment_method">
<option value="cash">Cash</option>
<option value="card">Card</option>
<option value="jazzcash">JazzCash</option>
<option value="easypaisa">EasyPaisa</option>
<option value="bank">Bank</option>
</select><br>

<select name="status">
<option value="paid">Paid</option>
<option value="pending">Pending</option>
<option value="failed">Failed</option>
</select><br>

<input type="text" name="transaction_id" placeholder="Transaction ID (optional)"><br>

<input type="hidden" name="book-appointment_id" value=""><!-- optional -->

<button name="submit">Save</button>
</form>
<?php
include "db.php";

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM payments WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: payments.php");
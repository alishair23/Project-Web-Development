<?php
include "db.php";

if(isset($_POST['submit'])){
    $name = $_POST['doctor_name'];
    $spec = $_POST['specialization'];
    $phone = $_POST['phone'];

    $stmt = $conn->prepare("INSERT INTO doctors (doctor_name, specialization, phone) VALUES (?,?,?)");
    $stmt->bind_param("sss",$name,$spec,$phone);
    $stmt->execute();

    header("Location: doctors.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Doctor</title>

<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
    --bg:#F8FAFC;
}

/* BODY */
body{
    font-family:'Poppins', sans-serif;
    background:var(--bg);
    margin:0;
    padding:40px;
}

/* CONTAINER */
.container{
    max-width:450px;
    margin:auto;
    background:white;
    padding:30px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TITLE */
h2{
    text-align:center;
    color:var(--primary);
    margin-bottom:20px;
}

/* INPUT */
input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:8px;
    border:1px solid #ddd;
    outline:none;
    transition:0.3s;
}

input:focus{
    border-color:var(--primary);
    box-shadow:0 0 8px rgba(59,130,246,0.3);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    transform:scale(1.05);
    background:linear-gradient(90deg,var(--secondary),var(--accent));
}
</style>
</head>

<body>

<div class="container">

<h2> Add Doctor</h2>

<form method="POST">
<input type="text" name="doctor_name" placeholder="Doctor Name" required><br>
<input type="text" name="specialization" placeholder="Specialization"><br>
<input type="text" name="phone" placeholder="Phone"><br>
<button name="submit">Save</button>
</form>

</div>

</body>
</html>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include(__DIR__ . "/db.php");

// ✅ Check login
if (!isset($_SESSION['user_id'])) {
    die("User not logged in!");
}

$user_id = $_SESSION['user_id'];

// ✅ Get patient info
$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();

// ❗ IMPORTANT CHECK
if (!$patient) {
    die("Patient not linked!");
}

// ✅ Get appointments
$query = "
SELECT 
    appointments.*, 
    patients.name AS patient_name,
    doctors.doctor_name
FROM appointments
JOIN patients ON appointments.patient_id = patients.id
JOIN doctors ON appointments.doctor_id = doctors.doctor_id
WHERE patients.user_id = ?
ORDER BY appointment_date DESC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<title>My Appointments</title>

<style>
body {
    font-family: Arial;
    background: #f4f6f9;
    padding: 20px;
}

h2 {
    margin-bottom: 15px;
}

.btn {
    background: green;
    color: white;
    padding: 10px 15px;
    text-decoration: none;
    border-radius: 5px;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    margin-top: 15px;
}

th, td {
    padding: 10px;
    border: 1px solid #ddd;
}

th {
    background: #333;
    color: white;
}

.action a {
    margin-right: 5px;
    text-decoration: none;
    padding: 5px 8px;
    border-radius: 4px;
    color: white;
}

.edit { background: orange; }
.delete { background: red; }
</style>

</head>

<body>

<h2>📅 My Appointments</h2>

<a href="add_appointments.php" class="btn">+ Book Appointment</a>
<a href="add_prescription.php?id=<?= $row['id'] ?>">
    ➕ Add Prescription
</a>

<table>
<tr>
    <th>ID</th>
    <th>Patient</th>
    <th>Doctor</th>
    <th>Date</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php if($result->num_rows > 0): ?>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['patient_name']) ?></td>
        <td><?= htmlspecialchars($row['doctor_name']) ?></td>
        <td><?= $row['appointment_date'] ?></td>
        <td><?= $row['status'] ?></td>
        <td class="action">
            <a class="edit" href="edit_appointment.php?id=<?= $row['id'] ?>">Edit</a>
            <a class="delete" href="delete_appointment.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>
<?php else: ?>
<tr>
    <td colspan="6">No appointments found</td>
</tr>
<?php endif; ?>

</table>

</body>
</html>
<?php
include "db.php";

$result = $conn->query("
    SELECT a.*, d.doctor_name AS doctor, p.name AS patient
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.doctor_id
    JOIN patients p ON a.patient_id = p.id
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Doctor Appointments</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body {
    background: linear-gradient(135deg,#0f2027,#203a43,#2c5364);
    color: white;
    font-family: 'Segoe UI';
}

/* CARD VIEW */
.app-card {
    background: rgba(255,255,255,0.1);
    border-radius: 15px;
    padding: 15px;
    margin-bottom: 15px;
    transition: 0.3s;
}

.app-card:hover {
    transform: scale(1.02);
}

/* TABLE */
.table {
    background: rgba(255,255,255,0.1);
    border-radius: 10px;
    overflow: hidden;
}

.table th {
    background: rgba(0,0,0,0.5);
    color: white;
}

.table td {
    color: #eee;
}

/* BUTTON */
.btn-action {
    background: linear-gradient(45deg,#00c6ff,#0072ff);
    border: none;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
}

</style>
</head>

<body class="p-4">

<h2>👨‍⚕️ Doctor Appointments</h2>

<!-- CARD VIEW -->
<?php mysqli_data_seek($result, 0); ?>
<?php while($row = $result->fetch_assoc()): ?>
<div class="app-card">
    <b>Patient:</b> <?= $row['patient'] ?><br>
    <b>Doctor:</b> <?= $row['doctor'] ?><br>
    <b>Date:</b> <?= $row['appointment_date'] ?><br>
    <b>Status:</b> <?= $row['status'] ?>
</div>
<?php endwhile; ?>

<!-- RESET RESULT POINTER -->
<?php mysqli_data_seek($result, 0); ?>

<!-- TABLE VIEW -->
<table class="table table-bordered mt-4">
<tr>
<th>Patient</th>
<th>Doctor</th>
<th>Date</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
<td><?= $row['patient'] ?></td>
<td><?= $row['doctor'] ?></td>
<td><?= $row['appointment_date'] ?></td>
<td><?= $row['status'] ?></td>
<td>
<a href="add_prescription.php?id=<?= $row['id'] ?>" class="btn-action">
➕ Add Prescription
</a>
</td>
</tr>
<?php endwhile; ?>
</table>

</body>
</html>
<?php
session_start();
include "db.php";

if(isset($_POST['submit'])){

    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $phone   = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $dob     = $_POST['dob'];

    /* OPTIONAL: link to logged-in user */
    $user_id = $_SESSION['user_id'] ?? NULL;

    $stmt = $conn->prepare("
        INSERT INTO patients (name,email,phone,address,dob,user_id)
        VALUES (?,?,?,?,?,?)
    ");

    $stmt->bind_param("sssssi", $name,$email,$phone,$address,$dob,$user_id);

    if($stmt->execute()){
        header("Location: patients.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Patient</title>

<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
    --bg:#F8FAFC;
}

/* BODY */
body{
    font-family:'Poppins', sans-serif;
    background:var(--bg);
    margin:0;
    padding:40px;
}

/* CONTAINER */
.container{
    max-width:500px;
    margin:auto;
    background:white;
    padding:30px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TITLE */
h2{
    text-align:center;
    color:var(--primary);
    margin-bottom:20px;
}

/* INPUTS */
input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:8px;
    border:1px solid #ddd;
    outline:none;
    transition:0.3s;
}

input:focus{
    border-color:var(--primary);
    box-shadow:0 0 8px rgba(59,130,246,0.3);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    transform:scale(1.05);
    background:linear-gradient(90deg,var(--secondary),var(--accent));
}
</style>
</head>

<body>

<div class="container">

<h2>Add Patient</h2>

<form method="POST">
    <input type="text" name="name" placeholder="Name" required><br>
    <input type="email" name="email" placeholder="Email"><br>
    <input type="text" name="phone" placeholder="Phone"><br>
    <input type="text" name="address" placeholder="Address"><br>
    <input type="date" name="dob"><br>
    <button name="submit">Save</button>
</form>

</div>

</body>
</html>
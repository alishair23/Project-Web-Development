<?php
session_start();
include "db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: index.html");
    exit();
}

$result = $conn->query("SELECT * FROM patients ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Patients</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
    --bg:#F8FAFC;
}

body{
    margin:0;
    font-family:'Poppins', sans-serif;
    background:var(--bg);
    display:flex;
}

/* SIDEBAR */
.sidebar{
    width:250px;
    background:linear-gradient(180deg,var(--primary),green);
    color:white;
    height:100vh;
    padding:20px;
}

.sidebar h2{
    margin-bottom:25px;
}

.sidebar a{
    display:block;
    padding:12px;
    margin:8px 0;
    color:#e0f2fe;
    text-decoration:none;
    border-radius:8px;
}

.sidebar a:hover{
    background:linear-gradient(90deg,var(--secondary),var(--primary));
}

/* MAIN */
.main{
    flex:1;
    padding:25px;
}

/* HEADER */
.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    background:white;
    padding:15px;
    border-radius:10px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
}

/* ADD BUTTON */
.add-btn{
    background:var(--accent);
    color:white;
    padding:8px 12px;
    border-radius:6px;
    text-decoration:none;
}

/* TABLE BOX */
.table-box{
    margin-top:20px;
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:12px;
    text-align:left;
}

th{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
}

tr:hover{
    background:#e0f2fe;
}

/* ACTION BUTTONS */
.btn{
    padding:5px 8px;
    border-radius:5px;
    text-decoration:none;
    color:white;
}

.edit{ background:orange; }
.delete{ background:red; }
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h2>+MediCare</h2>
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="patients.php">Patients</a>
    <a href="appointments.php">Appointments</a>
    <a href="doctors.php">Doctors</a>
    <a href="admin_payments.php">Payments</a>
    <a href="admin_prescriptions.php">Prescriptions</a>
    <a href="logout.php">Logout</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="topbar">
    <h2>Patients</h2>
    <a href="add_patient.php" class="add-btn">+ Add Patient</a>
</div>

<div class="table-box">

<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th>Address</th>
<th>DOB</th>
<th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
<td><?= $row['id'] ?></td>
<td><?= htmlspecialchars($row['name']) ?></td>
<td><?= htmlspecialchars($row['email']) ?></td>
<td><?= $row['phone'] ?></td>
<td><?= $row['address'] ?></td>
<td><?= $row['dob'] ?></td>
<td>
<a class="btn edit" href="edit_patient.php?id=<?= $row['id'] ?>">Edit</a>
<a class="btn delete" href="delete_patient.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
</td>
</tr>
<?php endwhile; ?>

</table>

</div>

</div>

</body>
</html>
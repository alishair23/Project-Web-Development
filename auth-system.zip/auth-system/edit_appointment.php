<?php
include "db.php";

$id = $_GET['id'];

$data = $conn->query("SELECT * FROM appointments WHERE id=$id")->fetch_assoc();
$patients = $conn->query("SELECT id,name FROM patients");

if(isset($_POST['update'])){
    $stmt = $conn->prepare("
        UPDATE appointments 
        SET patient_id=?, doctor_name=?, appointment_date=?, status=? 
        WHERE id=?
    ");

    $stmt->bind_param(
        "isssi",
        $_POST['patient_id'],
        $_POST['doctor_name'],
        $_POST['appointment_date'],
        $_POST['status'],
        $id
    );

    $stmt->execute();
    header("Location: appointments.php");
}
?>

<form method="POST">

<select name="patient_id">
<?php while($p = $patients->fetch_assoc()): ?>
<option value="<?= $p['id'] ?>" <?= $p['id']==$data['patient_id']?'selected':'' ?>>
<?= $p['name'] ?>
</option>
<?php endwhile; ?>
</select><br>

<input type="text" name="doctor_name" value="<?= $data['doctor_name'] ?>"><br>
<input type="datetime-local" name="appointment_date" value="<?= date('Y-m-d\TH:i', strtotime($data['appointment_date'])) ?>"><br>

<select name="status">
<option <?= $data['status']=='pending'?'selected':'' ?>>pending</option>
<option <?= $data['status']=='confirmed'?'selected':'' ?>>confirmed</option>
<option <?= $data['status']=='completed'?'selected':'' ?>>completed</option>
<option <?= $data['status']=='cancelled'?'selected':'' ?>>cancelled</option>
</select><br>

<button name="update">Update</button>
</form>
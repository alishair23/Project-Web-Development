<?php
session_start();
require_once "db.php";

// Check DB connection
if (!$conn) {
    die("Database connection failed!");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // ===== GET FORM DATA =====
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    // ===== VALIDATION =====
    if (empty($username) || empty($email) || empty($password)) {
        die("All fields are required!");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format!");
    }

    if ($password !== $confirm) {
        die("Passwords do not match!");
    }

    if (strlen($password) < 6) {
        die("Password must be at least 6 characters!");
    }

    // ===== CHECK DUPLICATE EMAIL =====
    $check = $conn->prepare("SELECT id FROM users WHERE email=?");
    if (!$check) {
        die("Prepare failed: " . $conn->error);
    }

    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        die("Email already exists!");
    }
    $check->close();

    // ===== HASH PASSWORD =====
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // ===== INSERT USER =====
    $stmt = $conn->prepare("
        INSERT INTO users (username, email, password)
        VALUES (?, ?, ?)
    ");

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sss", $username, $email, $hashedPassword);

    if ($stmt->execute()) {

        // ===== GET NEW USER ID =====
        $user_id = $conn->insert_id;

        // ===== INSERT PATIENT (LINK USER) =====
        $stmt2 = $conn->prepare("
            INSERT INTO patients (name, email, user_id)
            VALUES (?, ?, ?)
        ");

        if (!$stmt2) {
            die("Prepare failed (patients): " . $conn->error);
        }

        // ✅ THIS LINE WAS CAUSING YOUR ERROR BEFORE
        $stmt2->bind_param("ssi", $username, $email, $user_id);

        $stmt2->execute();
        $stmt2->close();

        // ===== SUCCESS =====
        $_SESSION['success'] = "Registration successful!";

        header("Location: login.html");
        exit();

    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
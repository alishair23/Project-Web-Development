<?php
include "db.php";

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM doctors WHERE doctor_id=?");
$stmt->bind_param("i",$id);
$stmt->execute();

header("Location: doctors.php");
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();

$patient = $stmt->get_result()->fetch_assoc();

if(!$patient){
    die("Patient not linked");
}
?>
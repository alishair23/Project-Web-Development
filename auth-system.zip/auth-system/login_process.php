<?php
session_start();
require_once "db.php";

/* ================= CHECK REQUEST ================= */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Invalid request!");
}

/* ================= SAFE INPUT ================= */
$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if (empty($username) || empty($password)) {
    die("Please fill all fields!");
}

/* ================= QUERY ================= */
$stmt = $conn->prepare("SELECT * FROM users WHERE username=?");

if (!$stmt) {
    die("SQL Error: " . $conn->error);
}

$stmt->bind_param("s", $username);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

/* ================= VERIFY ================= */
if ($user && password_verify($password, $user['password'])) {

    session_regenerate_id(true);

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role']    = $user['role'] ?? 'user';

    /* ================= REDIRECT ================= */
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin_dashboard.php");
    } else {
        header("Location: user_dashboard.php");
    }
    exit();

} else {
    echo "Invalid username or password";
}
?>
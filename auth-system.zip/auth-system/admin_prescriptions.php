<?php
session_start();
require_once "db.php";

// 🔥 SHOW ERRORS (disable in production)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// ✅ ADMIN CHECK
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access denied!");
}

/* ================= ADD ================= */
if (isset($_POST['add'])) {

    $appointment_id = (int) ($_POST['appointment_id'] ?? 0);
    $notes = trim($_POST['notes'] ?? '');
    $medicines = trim($_POST['medicines'] ?? '');

    if ($appointment_id <= 0 || empty($notes) || empty($medicines)) {
        die("All fields are required!");
    }

    $stmt = $conn->prepare("
        INSERT INTO prescriptions (appointment_id, notes, medicines)
        VALUES (?, ?, ?)
    ");
    $stmt->bind_param("iss", $appointment_id, $notes, $medicines);
    $stmt->execute();

    header("Location: admin_prescriptions.php");
    exit();
}

/* ================= DELETE ================= */
if (isset($_GET['delete'])) {

    $id = (int) $_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM prescriptions WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: admin_prescriptions.php");
    exit();
}

/* ================= UPDATE ================= */
if (isset($_POST['update'])) {

    $id = (int) $_POST['id'];
    $notes = trim($_POST['notes']);
    $medicines = trim($_POST['medicines']);

    if ($id <= 0) {
        die("Invalid ID!");
    }

    $stmt = $conn->prepare("
        UPDATE prescriptions 
        SET notes=?, medicines=? 
        WHERE id=?
    ");
    $stmt->bind_param("ssi", $notes, $medicines, $id);
    $stmt->execute();

    header("Location: admin_prescriptions.php");
    exit();
}

/* ================= FETCH TABLE ================= */
$result = $conn->query("
SELECT 
    pr.id,
    pr.notes,
    pr.medicines,
    p.name AS patient_name,
    d.doctor_name,
    a.appointment_date
FROM prescriptions pr
LEFT JOIN appointments a ON pr.appointment_id = a.id
LEFT JOIN patients p ON a.patient_id = p.id
LEFT JOIN doctors d ON a.doctor_id = d.doctor_id
ORDER BY pr.id DESC
");

/* ================= DROPDOWN ================= */
$appointments = $conn->query("
SELECT 
    a.id, 
    p.name AS patient, 
    d.doctor_name
FROM appointments a
LEFT JOIN patients p ON a.patient_id = p.id
LEFT JOIN doctors d ON a.doctor_id = d.doctor_id
ORDER BY a.id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Prescriptions</title>

<style>
    body{
    font-family:'Segoe UI', sans-serif;
    background:#F8FAFC;
    color:#111827;
    padding:30px;
}

/* CARD */
.card{
    background:white;
    padding:20px;
    border-radius:16px;
    margin-bottom:25px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    position:relative;
    overflow:hidden;
}

/* top gradient border */
.card::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:5px;
    background:linear-gradient(90deg,#3B82F6,#06B6D4,#10B981);
}

/* HEADINGS */
h2{
    color:#3B82F6;
}
h3{
    margin-bottom:10px;
}

/* FORM */
input,textarea,select{
    width:100%;
    padding:10px;
    margin:6px 0;
    border-radius:8px;
    border:1px solid #e2e8f0;
    outline:none;
    transition:0.3s;
}

/* INPUT FOCUS */
input:focus, textarea:focus, select:focus{
    border-color:#3B82F6;
    box-shadow:0 0 8px rgba(59,130,246,0.3);
}

/* BUTTON */
button{
    padding:10px 14px;
    background:linear-gradient(90deg,#3B82F6,#06B6D4);
    border:none;
    color:white;
    border-radius:8px;
    cursor:pointer;
    transition:0.3s;
}
button:hover{
    transform:scale(1.05);
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:10px;
}

th,td{
    padding:12px;
    text-align:left;
}

th{
    background:linear-gradient(90deg,#3B82F6,#06B6D4);
    color:white;
}

tr{
    transition:0.2s;
}

tr:nth-child(even){
    background:#f1f5f9;
}

tr:hover{
    background:#e0f2fe;
}

/* ACTION BUTTONS */
.btn{
    padding:6px 10px;
    border-radius:6px;
    text-decoration:none;
    color:white;
    transition:0.3s;
}

/* COLORS */
.delete{
    background:#ef4444;
}

.edit{
    background:#f59e0b;
}

/* HOVER */
.btn:hover{
    transform:scale(1.05);
    opacity:0.9;
}
</style>
</head>

<body>

<h2> Admin Prescriptions</h2>

<!-- ================= ADD ================= -->
<div class="card">
<h3>Add Prescription</h3>

<form method="POST">

<select name="appointment_id" required>
<option value="">Select Appointment</option>

<?php if($appointments && $appointments->num_rows > 0): ?>
    <?php while($a = $appointments->fetch_assoc()): ?>
    <option value="<?= (int)$a['id'] ?>">
        #<?= $a['id'] ?> - 
        <?= htmlspecialchars($a['patient'] ?? 'No Patient') ?> 
        (<?= htmlspecialchars($a['doctor_name'] ?? 'No Doctor') ?>)
    </option>
    <?php endwhile; ?>
<?php else: ?>
    <option>No appointments found</option>
<?php endif; ?>

</select>

<textarea name="notes" placeholder="Doctor Notes" required></textarea>
<textarea name="medicines" placeholder="Medicines" required></textarea>

<button name="add">Add Prescription</button>

</form>
</div>

<!-- ================= TABLE ================= -->
<div class="card">

<table>
<tr>
<th>ID</th>
<th>Patient</th>
<th>Doctor</th>
<th>Date</th>
<th>Notes</th>
<th>Medicines</th>
<th>Action</th>
</tr>

<?php if($result && $result->num_rows > 0): ?>
<?php while($row = $result->fetch_assoc()): ?>
<tr>

<td><?= $row['id'] ?></td>

<td><?= htmlspecialchars($row['patient_name'] ?? 'N/A') ?></td>

<td><?= htmlspecialchars($row['doctor_name'] ?? 'N/A') ?></td>

<td><?= htmlspecialchars($row['appointment_date'] ?? 'N/A') ?></td>

<td><?= htmlspecialchars($row['notes']) ?></td>

<td><?= htmlspecialchars($row['medicines']) ?></td>

<td>

<form method="POST" style="display:inline;">
<input type="hidden" name="id" value="<?= $row['id'] ?>">
<input type="text" name="notes" value="<?= htmlspecialchars($row['notes']) ?>" style="width:120px;">
<input type="text" name="medicines" value="<?= htmlspecialchars($row['medicines']) ?>" style="width:120px;">
<button class="edit" name="update">Update</button>
</form>

<a class="btn delete" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete?')">Delete</a>

</td>

</tr>
<?php endwhile; ?>
<?php else: ?>
<tr><td colspan="7">No prescriptions found</td></tr>
<?php endif; ?>

</table>

</div>

</body>
</html>
<?php
session_start();
include "db.php";

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM users WHERE id=$id");
$user = $result->fetch_assoc();
?>
<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
}

/* BODY */
body{
    font-family:'Segoe UI', sans-serif;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    color:#e2e8f0;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

/* FORM CARD */
form{
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(12px);

    padding:30px;
    border-radius:15px;

    width:300px;
    text-align:center;

    box-shadow:0 10px 30px rgba(0,0,0,0.4);
    position:relative;
}

/* TOP GRADIENT LINE */
form::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:4px;
    background:linear-gradient(90deg,var(--primary),var(--secondary),var(--accent));
}

/* INPUT + SELECT */
input, select{
    width:100%;
    padding:10px;
    margin:10px 0;

    border:none;
    border-radius:8px;
    outline:none;

    background:rgba(255,255,255,0.1);
    color:white;

    transition:0.3s;
}

/* FOCUS */
input:focus, select:focus{
    box-shadow:0 0 10px var(--primary);
}

/* BUTTON */
button{
    width:100%;
    padding:10px;
    margin-top:10px;

    border:none;
    border-radius:20px;

    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
    font-weight:bold;

    cursor:pointer;
    transition:0.3s;
}

/* HOVER */
button:hover{
    transform:scale(1.05);
    background:linear-gradient(90deg,var(--secondary),var(--primary));
}
</style>
<form action="update_user.php" method="POST">
<input type="hidden" name="id" value="<?= $user['id'] ?>">
<input type="text" name="username" value="<?= $user['username'] ?>"><br>

<select name="role">
<option value="user">User</option>
<option value="admin">Admin</option>
</select><br>

<button type="submit">Update</button>
</form>

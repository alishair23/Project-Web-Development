<?php
include "php/db.php";

/* =======================
   TOTAL APPOINTMENTS
======================= */
$appointmentsQuery = "SELECT COUNT(*) as total FROM appointments";
$appointmentsResult = $conn->query($appointmentsQuery);

if ($appointmentsResult) {
    $totalAppointments = $appointmentsResult->fetch_assoc()['total'];
} else {
    $totalAppointments = 0;
}

/* =======================
   TOTAL PATIENTS
======================= */
$patientsQuery = "SELECT COUNT(DISTINCT phone) as total FROM appointments";
$patientsResult = $conn->query($patientsQuery);

if ($patientsResult) {
    $totalPatients = $patientsResult->fetch_assoc()['total'];
} else {
    $totalPatients = 0;
}

/* =======================
   TOTAL DOCTORS
======================= */
$doctorsQuery = "SELECT COUNT(*) as total FROM doctors";
$doctorsResult = $conn->query($doctorsQuery);

if ($doctorsResult) {
    $totalDoctors = $doctorsResult->fetch_assoc()['total'];
} else {
    $totalDoctors = 0;
}

/* =======================
   APPOINTMENTS LIST
======================= */
$sql = "SELECT * FROM appointments ORDER BY date DESC";
$result = $conn->query($sql);
?>
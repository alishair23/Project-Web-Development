<?php
include 'db.php';
$email=$_POST['email'];
$pass=$_POST['password'];
$result=$conn->query("SELECT * FROM users WHERE email='$email' AND password='$pass'");
if($result->num_rows>0){
echo "Login Success";
}else{
echo "Failed";
}
?>
<?php
include "db.php";

$name = $_POST['name'];
$phone = $_POST['phone'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$doctor = $_POST['doctor'];
$date = $_POST['date'];
$symptoms = $_POST['symptoms'];

$sql = "INSERT INTO appointments 
(patient_name, phone, age, gender, doctor, date, symptoms)
VALUES 
('$name', '$phone', '$age', '$gender', '$doctor', '$date', '$symptoms')";

$conn->query($sql);

echo "Appointment Booked Successfully";
?>
<?php
$conn = new mysqli('localhost','root','','clinic');
if($conn->connect_error){
die('DB Failed');
}
?>
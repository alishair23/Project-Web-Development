<?php
include 'db.php';
$res=$conn->query("SELECT * FROM appointments");
while($row=$res->fetch_assoc()){
echo $row['patient_name']." - ".$row['doctor']." - ".$row['app_date']."<br>";
}
?>
<?php
session_start();
require_once "db.php";

/* ================= LOGIN CHECK ================= */
if (!isset($_SESSION['user_id'])) {
    die("Please login first!");
}

$user_id = $_SESSION['user_id'];

/* ================= GET PATIENT ================= */
$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();

if (!$patient) {
    die("Patient not found!");
}

$patient_id = $patient['id'];

/* ================= FETCH PAYMENTS ================= */
$stmt = $conn->prepare("
SELECT 
    payments.*, 
    doctors.doctor_name,
    appointments.appointment_date
FROM payments
LEFT JOIN appointments ON payments.appointment_id = appointments.id
LEFT JOIN doctors ON appointments.doctor_id = doctors.doctor_id
WHERE payments.patient_id = ?
ORDER BY payments.created_at DESC
");

$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<title>My Payments</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
}

/* BODY */
body{
    font-family:'Poppins',sans-serif;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    color:#e2e8f0;
    padding:30px;
}

/* HEADER */
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

h2{
    color:var(--primary);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(12px);
    border-radius:12px;
    overflow:hidden;
    box-shadow:0 10px 25px rgba(0,0,0,0.3);
}

th, td{
    padding:14px;
    text-align:left;
}

th{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
}

tr{
    transition:0.2s;
}

tr:nth-child(even){
    background:rgba(255,255,255,0.03);
}

tr:hover{
    background:rgba(59,130,246,0.15);
}

/* STATUS */
.status{
    padding:5px 10px;
    border-radius:6px;
    font-size:12px;
    font-weight:600;
}

.pending{ background:#f59e0b; color:black; }
.paid{ background:var(--accent); }

/* PAY BUTTON */
.pay{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    padding:6px 12px;
    border-radius:6px;
    color:white;
    text-decoration:none;
    transition:0.3s;
}

.pay:hover{
    background:linear-gradient(90deg,var(--secondary),var(--primary));
    transform:scale(1.05);
}

/* EMPTY */
td[colspan="5"]{
    text-align:center;
    color:#94a3b8;
}
</style>
</head>

<body>

<div class="header">
    <h2>My Payments</h2>
</div>

<table>
<tr>
<th>Doctor</th>
<th>Date</th>
<th>Amount</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php if($result->num_rows > 0): ?>
<?php while($row = $result->fetch_assoc()): ?>
<tr>

<td><?= $row['doctor_name'] ?? 'N/A' ?></td>

<td><?= $row['appointment_date'] ?? 'N/A' ?></td>

<td>Rs. <?= number_format($row['amount'], 2) ?></td>

<td>
<span class="status <?= $row['status']=='paid' ? 'paid' : 'pending' ?>">
<?= ucfirst($row['status']) ?>
</span>
</td>

<td>
<?php if($row['status']=='pending'): ?>
<a class="pay" href="pay_now.php?id=<?= $row['id'] ?>">
 Pay Now
</a>
<?php else: ?>
✔ Paid
<?php endif; ?>
</td>

</tr>
<?php endwhile; ?>
<?php else: ?>
<tr>
<td colspan="5">No payments found</td>
</tr>
<?php endif; ?>

</table>

</body>
</html>
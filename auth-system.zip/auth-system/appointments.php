<?php
session_start();
include "db.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

$query = "
SELECT a.*, p.name AS patient, d.doctor_name
FROM appointments a
JOIN patients p ON a.patient_id = p.id
JOIN doctors d ON a.doctor_id = d.doctor_id
ORDER BY a.id DESC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Appointments</title>

<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
    --bg:#F8FAFC;
}

/* BODY */
body{
    font-family:'Poppins', sans-serif;
    background:var(--bg);
    margin:0;
    padding:30px;
}

/* TITLE */
h2{
    text-align:center;
    color:var(--primary);
    margin-bottom:20px;
}

/* TABLE CONTAINER */
.table-box{
    width:95%;
    margin:auto;
    background:white;
    padding:20px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th, td{
    padding:12px;
    text-align:center;
}

th{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
}

tr{
    transition:0.2s;
}

tr:nth-child(even){
    background:#f1f5f9;
}

tr:hover{
    background:#e0f2fe;
}

/* BUTTONS */
.btn{
    padding:6px 10px;
    border-radius:6px;
    color:white;
    text-decoration:none;
    font-size:13px;
    transition:0.3s;
}

.approve{
    background:var(--accent);
}

.reject{
    background:#ef4444;
}

.btn:hover{
    transform:scale(1.05);
    opacity:0.9;
}

/* STATUS BADGE */
.status{
    padding:5px 10px;
    border-radius:6px;
    font-size:12px;
    color:white;
}

.pending{ background:#f59e0b; }
.approved{ background:var(--accent); }
.rejected{ background:#ef4444; }

</style>
</head>

<body>

<h2>Appointments Dashboard</h2>

<div class="table-box">

<table>
<tr>
    <th>ID</th>
    <th>Patient</th>
    <th>Doctor</th>
    <th>Date</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= htmlspecialchars($row['patient']) ?></td>
    <td><?= htmlspecialchars($row['doctor_name']) ?></td>
    <td><?= $row['appointment_date'] ?></td>

    <td>
        <span class="status <?= strtolower($row['status']) ?>">
            <?= ucfirst($row['status']) ?>
        </span>
    </td>

    <td>
        <a class="btn approve" href="update_status.php?id=<?= $row['id'] ?>&status=approved">Approve</a>
        <a class="btn reject" href="update_status.php?id=<?= $row['id'] ?>&status=rejected">Reject</a>
    </td>
</tr>
<?php endwhile; ?>

</table>

</div>

</body>
</html>
<?php
session_start();
include "db.php";

$id = $_POST['id'];
$username = $_POST['username'];
$role = $_POST['role'];

$stmt = $conn->prepare("UPDATE users SET username=?, role=? WHERE id=?");
$stmt->bind_param("ssi", $username, $role, $id);
$stmt->execute();

header("Location: admin_dashboard.php");
?>

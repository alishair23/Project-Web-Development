<?php
session_start();
include "db.php";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (!isset($_SESSION['user_id'])) {
    die("Please login first!");
    
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT id FROM patients WHERE user_id=? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();

if (!$patient) {
    die("Patient not linked!");
}

$patient_id = (int)$patient['id'];

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];

    $stmt = $conn->prepare("
        DELETE FROM appointments 
        WHERE id=? AND patient_id=?
    ");
    $stmt->bind_param("ii", $id, $patient_id);
    $stmt->execute();

    header("Location: book_appointment.php");
    exit();
}

if (isset($_GET['cancel'])) {
    $id = (int) $_GET['cancel'];

    $stmt = $conn->prepare("
        UPDATE appointments 
        SET status='cancelled' 
        WHERE id=? AND patient_id=?
    ");
    $stmt->bind_param("ii", $id, $patient_id);
    $stmt->execute();

    header("Location: book_appointment.php");
    exit();
}

$stmt = $conn->prepare("
SELECT 
    a.id,
    a.appointment_date,
    a.status,
    d.doctor_name,
    d.specialization
FROM appointments a
LEFT JOIN doctors d ON a.doctor_id = d.doctor_id
WHERE a.patient_id = ?
ORDER BY a.appointment_date DESC
");

$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<title>My Appointments</title>

<style>
    
    :root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
}

body{
    font-family:Arial;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    color:#e2e8f0;
    padding:30px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.btn{
    padding:8px 12px;
    border-radius:6px;
    text-decoration:none;
    color:white;
    font-size:14px;
    transition:0.3s;
}

.add{
    background:linear-gradient(90deg,var(--accent),#059669);
}
.delete{
    background:linear-gradient(90deg,#ef4444,#dc2626);
}
.cancel{
    background:linear-gradient(90deg,#f59e0b,#d97706);
}

/* HOVER */
.btn:hover{
    transform:scale(1.05);
    box-shadow:0 5px 15px rgba(0,0,0,0.4);
}

/* CARD */
.card{
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(10px);
    padding:18px;
    border-radius:12px;
    margin-top:15px;
    transition:0.3s;
    position:relative;
    overflow:hidden;
}

/* TOP GRADIENT LINE */
.card::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:4px;
    background:linear-gradient(90deg,var(--primary),var(--secondary),var(--accent));
}

/* HOVER */
.card:hover{
    transform:translateY(-5px);
    box-shadow:0 15px 30px rgba(0,0,0,0.4);
}

/* STATUS */
.status{
    padding:5px 10px;
    border-radius:6px;
    font-size:13px;
    font-weight:bold;
}

/* STATUS COLORS */
.pending{ background:#f59e0b; }
.confirmed{ background:var(--primary); }
.completed{ background:var(--accent); }
.cancelled{ background:#ef4444; }
</style>
</head>

<body>

<div class="header">
    <h2> My Appointments</h2>
    <a class="btn add" href="add_appointments.php">+ Book Appointment</a>
</div>

<?php if($result && $result->num_rows > 0): ?>

<?php while($row = $result->fetch_assoc()): ?>
<div class="card">

<b>Doctor:</b> <?= htmlspecialchars($row['doctor_name'] ?? 'N/A') ?><br>
<b>Specialization:</b> <?= htmlspecialchars($row['specialization'] ?? 'N/A') ?><br>
<b>Date:</b> <?= htmlspecialchars($row['appointment_date']) ?><br>

<b>Status:</b>
<span class="status <?= htmlspecialchars($row['status']) ?>">
<?= ucfirst($row['status']) ?>
</span>

<br><br>

<?php if($row['status'] !== 'cancelled' && $row['status'] !== 'completed'): ?>
<a class="btn cancel" href="?cancel=<?= $row['id'] ?>">Cancel</a>
<?php endif; ?>

<a class="btn delete" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete appointment?')">Delete</a>

</div>
<?php endwhile; ?>

<?php else: ?>

<p>No appointments found</p>

<?php endif; ?>

</body>
</html>
<?php
include "db.php";
$result = $conn->query("SELECT * FROM doctors");
?>

<!DOCTYPE html>
<html>
<head>
<title>Doctors</title>

<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
    --bg:#F8FAFC;
}

/* BODY */
body{
    font-family:'Poppins', sans-serif;
    background:var(--bg);
    padding:30px;
}

/* TITLE */
h2{
    color:var(--primary);
    margin-bottom:15px;
}

/* BUTTON */
.btn-add{
    display:inline-block;
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
    padding:10px 15px;
    border-radius:8px;
    text-decoration:none;
    margin-bottom:15px;
    transition:0.3s;
}

.btn-add:hover{
    background:linear-gradient(90deg,var(--secondary),var(--accent));
    transform:scale(1.05);
}

/* TABLE CONTAINER */
.table-box{
    background:white;
    padding:20px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th, td{
    padding:12px;
    text-align:center;
}

th{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
}

tr:nth-child(even){
    background:#f1f5f9;
}

tr:hover{
    background:#e0f2fe;
}

/* ACTION BUTTONS */
.btn{
    padding:6px 10px;
    border-radius:6px;
    text-decoration:none;
    color:white;
    font-size:13px;
    margin:2px;
    display:inline-block;
    transition:0.3s;
}

.edit{
    background:#f59e0b;
}

.delete{
    background:#ef4444;
}

.btn:hover{
    transform:scale(1.05);
    opacity:0.9;
}
</style>

</head>

<body>

<h2> Doctors</h2>

<a href="add_doctor.php" class="btn-add">+ Add Doctor</a>

<div class="table-box">

<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Specialization</th>
<th>Phone</th>
<th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
<td><?= $row['doctor_id'] ?></td>
<td><?= htmlspecialchars($row['doctor_name']) ?></td>
<td><?= htmlspecialchars($row['specialization']) ?></td>
<td><?= $row['phone'] ?></td>
<td>
<a href="edit_doctor.php?id=<?= $row['doctor_id'] ?>" class="btn edit">Edit</a>
<a href="delete_doctor.php?id=<?= $row['doctor_id'] ?>" class="btn delete" onclick="return confirm('Delete?')">Delete</a>
</td>
</tr>
<?php endwhile; ?>

</table>

</div>

</body>
</html>
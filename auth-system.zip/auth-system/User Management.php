<?php
include "db.php";

// Fetch users
$result = $conn->query("SELECT * FROM users");
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Management</title>
    <style>
        :root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
}

/* BODY */
body{
    font-family:'Segoe UI', sans-serif;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    color:#e2e8f0;
    padding:30px;
}

/* TITLE */
h1{
    color:var(--primary);
    margin-bottom:20px;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;

    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(12px);

    border-radius:12px;
    overflow:hidden;

    box-shadow:0 10px 25px rgba(0,0,0,0.3);
}

/* HEADER */
th{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
    padding:12px;
    text-align:left;
}

/* CELLS */
td{
    padding:12px;
}

/* ROW EFFECT */
tr{
    transition:0.2s;
}

tr:nth-child(even){
    background:rgba(255,255,255,0.03);
}

tr:hover{
    background:rgba(59,130,246,0.15);
}

/* LINKS */
a{
    text-decoration:none;
    padding:6px 10px;
    border-radius:6px;
    margin-right:5px;
    font-size:13px;
    transition:0.3s;
}

/* EDIT BUTTON */
a[href*="edit"]{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
}

a[href*="edit"]:hover{
    transform:scale(1.05);
}

/* DELETE BUTTON */
a[href*="delete"]{
    background:#ef4444;
    color:white;
}

a[href*="delete"]:hover{
    background:#dc2626;
}
    </style>
</head>
<body>

<h1>User Management</h1>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Role</th>
        <th>Action</th>
    </tr>

    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['username'] ?></td>
        <td><?= $row['role'] ?></td>
        <td>
            <a href="edit_user.php?id=<?= $row['id'] ?>">Edit</a>
            <a href="delete_user.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>

</table>

</body>
</html>
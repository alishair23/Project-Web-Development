<?php
session_start();
include "db.php";

// ✅ LOGIN CHECK
if (!isset($_SESSION['user_id'])) {
    die("Please login first!");
}

$user_id = $_SESSION['user_id'];

// ✅ GET PATIENT
$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();

if (!$patient) {
    die("Patient not linked!");
}

$patient_id = $patient['id'];

// ✅ FETCH DOCTORS
$doctors = $conn->query("SELECT * FROM doctors");

// ✅ ADD APPOINTMENT
if (isset($_POST['submit'])) {

    $doctor_id = (int) $_POST['doctor_id'];
    $date = $_POST['appointment_date'];
    $reason = $_POST['reason'];

    if (!$doctor_id || !$date) {
        die("Doctor and date required!");
    }

    $stmt = $conn->prepare("
        INSERT INTO appointments 
        (patient_id, doctor_id, appointment_date, reason, status)
        VALUES (?, ?, ?, ?, 'pending')
    ");

    if (!$stmt) {
        die("Error: " . $conn->error);
    }

    $stmt->bind_param("iiss", $patient_id, $doctor_id, $date, $reason);
    $stmt->execute();

    header("Location: book_appointment.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Book Appointment</title>

<style>
body{
    font-family:Arial;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    color:white;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.card{
    width:400px;
    background:#1e293b;
    padding:25px;
    border-radius:10px;
}

input,select,textarea{
    width:100%;
    padding:10px;
    margin:10px 0;
    border-radius:5px;
    border:none;
}

button{
    width:100%;
    padding:12px;
    background:#3b82f6;
    color:white;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

button:hover{
    background:#2563eb;
}
</style>
</head>

<body>

<div class="card">

<h2> Book Appointment</h2>

<form method="POST">

<label>Select Doctor</label>
<select name="doctor_id" required>
<option value="">Choose Doctor</option>

<?php while($d = $doctors->fetch_assoc()): ?>
<option value="<?= $d['doctor_id'] ?>">
<?= $d['doctor_name'] ?> (<?= $d['specialization'] ?>)
</option>
<?php endwhile; ?>

</select>

<label>Date & Time</label>
<input type="datetime-local" name="appointment_date" required>

<label>Reason</label>
<textarea name="reason" placeholder="Enter reason"></textarea>

<button name="submit">Book Appointment</button>

</form>

</div>

</body>
</html>
<?php
session_start();
require_once "db.php";

/* ================= SECURITY ================= */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access denied!");
}

/* ================= ADD PAYMENT ================= */
if (isset($_POST['add_payment'])) {

    $patient_id     = (int) $_POST['patient_id'];
    $appointment_id = !empty($_POST['appointment_id']) ? (int)$_POST['appointment_id'] : NULL;
    $amount         = (float) $_POST['amount'];

    if ($amount <= 0) {
        die("Invalid amount!");
    }

    // ✅ Validate appointment exists
    if ($appointment_id !== NULL) {
        $check = $conn->prepare("SELECT id FROM appointments WHERE id=?");
        $check->bind_param("i", $appointment_id);
        $check->execute();
        $res = $check->get_result();

        if ($res->num_rows === 0) {
            die("Invalid appointment selected!");
        }
    }

    $stmt = $conn->prepare("
        INSERT INTO payments (patient_id, appointment_id, amount, status)
        VALUES (?, ?, ?, 'pending')
    ");

    $stmt->bind_param("iid", $patient_id, $appointment_id, $amount);
    $stmt->execute();

    header("Location: admin_payments.php");
    exit();
}

/* ================= MARK PAID ================= */
if (isset($_GET['pay_id'])) {

    $id = (int) $_GET['pay_id'];

    $stmt = $conn->prepare("UPDATE payments SET status='paid' WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: admin_payments.php");
    exit();
}

/* ================= DELETE ================= */
if (isset($_GET['delete'])) {

    $id = (int) $_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM payments WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: admin_payments.php");
    exit();
}

/* ================= UPDATE ================= */
if (isset($_POST['update_payment'])) {

    $id     = (int) $_POST['id'];
    $amount = (float) $_POST['amount'];
    $status = $_POST['status'];

    if ($amount <= 0) {
        die("Invalid amount!");
    }

    if (!in_array($status, ['pending', 'paid'])) {
        die("Invalid status!");
    }

    $stmt = $conn->prepare("
        UPDATE payments 
        SET amount=?, status=? 
        WHERE id=?
    ");

    $stmt->bind_param("dsi", $amount, $status, $id);
    $stmt->execute();

    header("Location: admin_payments.php");
    exit();
}

/* ================= FETCH DATA ================= */
$result = $conn->query("
SELECT 
    payments.*, 
    patients.name AS patient_name,
    doctors.doctor_name,
    appointments.appointment_date
FROM payments
LEFT JOIN patients ON payments.patient_id = patients.id
LEFT JOIN appointments ON payments.appointment_id = appointments.id
LEFT JOIN doctors ON appointments.doctor_id = doctors.doctor_id
ORDER BY payments.created_at DESC
");

/* ================= DROPDOWNS ================= */
$patients = $conn->query("SELECT id, name FROM patients");

$appointments = $conn->query("
SELECT 
    a.id,
    p.name AS patient,
    d.doctor_name
FROM appointments a
LEFT JOIN patients p ON a.patient_id = p.id
LEFT JOIN doctors d ON a.doctor_id = d.doctor_id
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Payments</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

<style>
body{
    font-family:'Poppins', sans-serif;
    background:#F8FAFC;
    color:#111827;
    padding:30px;
}

/* CARD */
.card{
    background:white;
    padding:20px;
    border-radius:16px;
    margin-bottom:25px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    position:relative;
    overflow:hidden;
}

/* top gradient border */
.card::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:5px;
    background:linear-gradient(90deg,#3B82F6,#06B6D4,#10B981);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:12px;
    text-align:left;
}

th{
    background:linear-gradient(90deg,#3B82F6,#06B6D4);
    color:white;
}

tr{
    transition:0.2s;
}

tr:nth-child(even){
    background:#f1f5f9;
}

tr:hover{
    background:#e0f2fe;
}

/* BUTTONS */
.btn{
    padding:6px 12px;
    border-radius:6px;
    color:white;
    text-decoration:none;
    border:none;
    cursor:pointer;
    transition:0.3s;
}

/* Buttons Colors */
.pay{
    background:#10B981;
}

.delete{
    background:#ef4444;
}

.edit{
    background:#f59e0b;
}

/* Hover Effects */
.btn:hover{
    transform:scale(1.05);
    opacity:0.9;
}

/* FORM */
input,select{
    padding:8px;
    margin:5px;
    border-radius:8px;
    border:1px solid #e2e8f0;
    outline:none;
    transition:0.3s;
}

/* Input focus */
input:focus, select:focus{
    border-color:#3B82F6;
    box-shadow:0 0 8px rgba(59,130,246,0.3);
}

/* HEADINGS */
h2{
    color:#3B82F6;
}

h3{
    margin-bottom:10px;
}
</style>
</head>

<body>

<h2>Admin Payments </h2>

<!-- ================= ADD PAYMENT ================= -->
<div class="card">
<h3>Add Payment</h3>

<form method="POST">

<select name="patient_id" required>
<option value="">Select Patient</option>
<?php while($p = $patients->fetch_assoc()): ?>
<option value="<?= $p['id'] ?>">
<?= htmlspecialchars($p['name']) ?>
</option>
<?php endwhile; ?>
</select>

<select name="appointment_id">
<option value="">No Appointment</option>
<?php while($a = $appointments->fetch_assoc()): ?>
<option value="<?= $a['id'] ?>">
#<?= $a['id'] ?> - <?= $a['patient'] ?> (<?= $a['doctor_name'] ?>)
</option>
<?php endwhile; ?>
</select>

<input type="number" step="0.01" name="amount" placeholder="Amount" required>

<button class="btn pay" name="add_payment">Add Payment</button>

</form>
</div>

<!-- ================= TABLE ================= -->
<div class="card">

<table>
<tr>
<th>ID</th>
<th>Patient</th>
<th>Doctor</th>
<th>Date</th>
<th>Amount</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>

<td><?= $row['id'] ?></td>

<td><?= htmlspecialchars($row['patient_name']) ?></td>

<td><?= $row['doctor_name'] ?? 'N/A' ?></td>

<td><?= $row['appointment_date'] ?? 'N/A' ?></td>

<td>Rs. <?= $row['amount'] ?></td>

<td><?= ucfirst($row['status']) ?></td>

<td>

<?php if($row['status']=='pending'): ?>
<a class="btn pay" href="?pay_id=<?= $row['id'] ?>">✔ Pay</a>
<?php endif; ?>

<form method="POST" style="display:inline;">
<input type="hidden" name="id" value="<?= $row['id'] ?>">
<input type="number" step="0.01" name="amount" value="<?= $row['amount'] ?>" style="width:80px;">
<select name="status">
<option value="pending" <?= $row['status']=='pending'?'selected':'' ?>>Pending</option>
<option value="paid" <?= $row['status']=='paid'?'selected':'' ?>>Paid</option>
</select>
<button class="btn edit" name="update_payment">Update</button>
</form>

<a class="btn delete" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete payment?')">Delete</a>

</td>

</tr>
<?php endwhile; ?>

</table>

</div>

</body>
</html>
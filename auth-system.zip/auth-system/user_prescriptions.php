<?php
session_start();
require_once "get_patient.php";

// 🔥 Enable error reporting (remove in production)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$patient_id = (int)$patient['id'];

// ✅ FETCH USER PRESCRIPTIONS
$stmt = $conn->prepare("
SELECT 
    pr.id,
    pr.notes,
    pr.medicines,
    a.appointment_date,
    d.doctor_name,
    d.specialization
FROM prescriptions pr
JOIN appointments a ON pr.appointment_id = a.id
LEFT JOIN doctors d ON a.doctor_id = d.doctor_id
WHERE a.patient_id = ?
ORDER BY a.appointment_date DESC
");

$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<title>My Prescriptions</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
}

/* BODY */
body{
    font-family:'Poppins',sans-serif;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    color:#e2e8f0;
    padding:30px;
}

/* HEADER */
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

/* TITLE */
h2{
    color:var(--primary);
}

/* CARD */
.card{
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(12px);
    padding:20px;
    border-radius:14px;
    margin-top:15px;
    transition:0.3s;
    position:relative;
    overflow:hidden;
}

/* TOP BORDER */
.card::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:4px;
    background:linear-gradient(90deg,var(--primary),var(--secondary),var(--accent));
}

/* HOVER */
.card:hover{
    transform:translateY(-5px);
    box-shadow:0 15px 35px rgba(0,0,0,0.4);
}

/* TITLE TEXT */
.title{
    font-size:18px;
    margin-bottom:10px;
    font-weight:600;
}

/* LABEL */
.label{
    color:#94a3b8;
    font-size:13px;
}

/* VALUE */
.value{
    margin-bottom:10px;
    color:#e2e8f0;
}

/* BADGE */
.badge{
    display:inline-block;
    padding:4px 10px;
    border-radius:6px;
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    font-size:12px;
    margin-left:8px;
}

/* EMPTY STATE */
.empty{
    margin-top:20px;
    color:#94a3b8;
    text-align:center;
    font-size:14px;
}
</style>
</head>

<body>

<div class="header">
    <h2> My Prescriptions</h2>
</div>

<?php if($result && $result->num_rows > 0): ?>

<?php while($row = $result->fetch_assoc()): ?>
<div class="card">

<div class="title">
    <?= htmlspecialchars($row['doctor_name'] ?? 'Doctor') ?>
    <span class="badge"><?= htmlspecialchars($row['specialization'] ?? 'General') ?></span>
</div>

<div class="label">Appointment Date</div>
<div class="value"><?= htmlspecialchars($row['appointment_date']) ?></div>

<div class="label">Doctor Notes</div>
<div class="value"><?= nl2br(htmlspecialchars($row['notes'])) ?></div>

<div class="label">Medicines</div>
<div class="value"><?= nl2br(htmlspecialchars($row['medicines'])) ?></div>

</div>
<?php endwhile; ?>

<?php else: ?>

<div class="empty">No prescriptions found</div>

<?php endif; ?>

</body>
</html>
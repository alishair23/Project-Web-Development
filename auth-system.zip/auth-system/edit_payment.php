<?php
session_start();
include "db.php";

// ADMIN CHECK
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    die("Access denied!");
}

$id = $_GET['id'] ?? 0;

// FETCH PAYMENT
$stmt = $conn->prepare("SELECT * FROM payments WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();

if(!$payment){
    die("Payment not found");
}

// UPDATE
if(isset($_POST['update'])){
    $amount = $_POST['amount'];
    $status = $_POST['status'];

    if($amount <= 0){
        $error = "Invalid amount!";
    } else {

        $stmt = $conn->prepare("
            UPDATE payments 
            SET amount=?, status=? 
            WHERE id=?
        ");
        $stmt->bind_param("dsi",$amount,$status,$id);
        $stmt->execute();

        header("Location: admin_payments.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Payment</title>

<style>
body{
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    font-family:Poppins;
    color:white;
}

.card{
    width:350px;
    padding:30px;
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(20px);
    border-radius:15px;
}

input,select{
    width:100%;
    padding:10px;
    margin:10px 0;
    border:none;
    border-radius:8px;
}

button{
    width:100%;
    padding:12px;
    background:#3b82f6;
    border:none;
    color:white;
    border-radius:8px;
}

.error{
    background:red;
    padding:10px;
    margin-bottom:10px;
}
</style>
</head>

<body>

<div class="card">
<h2>✏️ Edit Payment</h2>

<?php if(isset($error)): ?>
<div class="error"><?= $error ?></div>
<?php endif; ?>

<form method="POST">

<label>Amount</label>
<input type="number" step="0.01" name="amount" value="<?= $payment['amount'] ?>" required>

<label>Status</label>
<select name="status">
<option value="pending" <?= $payment['status']=='pending'?'selected':'' ?>>Pending</option>
<option value="paid" <?= $payment['status']=='paid'?'selected':'' ?>>Paid</option>
</select>

<button name="update">Update Payment</button>

</form>

</div>

</body>
</html>
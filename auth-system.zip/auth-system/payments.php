<?php
include "db.php";

$query = "
SELECT payments.*, patients.name AS patient_name
FROM payments
JOIN patients ON payments.patient_id = patients.id
ORDER BY payments.created_at DESC
";

$result = $conn->query($query);
?>

<h2>Payments</h2>
<a href="add_payment.php" class="btn" style="background:green;">+ Add Payment</a>

<table>
<tr>
    <th>ID</th>
    <th>Patient</th>
    <th>Amount</th>
    <th>Method</th>
    <th>Status</th>
    <th>Date</th>
    <th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= htmlspecialchars($row['patient_name']) ?></td>
    <td>Rs <?= $row['amount'] ?></td>
    <td><?= $row['payment_method'] ?></td>
    <td><?= $row['status'] ?></td>
    <td><?= $row['created_at'] ?></td>
    <td>
        <a class="btn edit" href="edit_payment.php?id=<?= $row['id'] ?>">Edit</a>
        <a class="btn delete" href="delete_payment.php?id=<?= $row['id'] ?>">Delete</a>
    </td>
</tr>
<?php endwhile; ?>
</table>
<?php include "get_patient.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Dashboard</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Icons -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>

/* ===== THEME COLORS ===== */
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
}

/* ===== BODY ===== */
body {
    background: linear-gradient(135deg, #0f172a, #1e293b);
    font-family: 'Segoe UI', sans-serif;
    color: #e2e8f0;
}

/* ===== SIDEBAR ===== */
.sidebar {
    position: fixed;
    width: 250px;
    height: 100%;
    background: rgba(15, 23, 42, 0.9);
    backdrop-filter: blur(12px);
    padding: 20px;
}

.sidebar h3 {
    text-align: center;
    margin-bottom: 30px;
    color: var(--primary);
}

/* LINKS */
.sidebar a {
    display: block;
    color: #cbd5f5;
    padding: 12px;
    margin: 8px 0;
    border-radius: 10px;
    text-decoration: none;
    transition: 0.3s;
}

/* HOVER */
.sidebar a:hover {
    background: linear-gradient(90deg, var(--primary), var(--secondary));
    color: white;
    transform: translateX(5px);
}

/* ===== MAIN ===== */
.main {
    margin-left: 260px;
    padding: 30px;
}

/* ===== CARD ===== */
.card-box {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(12px);
    border-radius: 20px;
    padding: 25px;
    text-align: center;
    height: 100%;
    transition: 0.3s;
    box-shadow: 0 10px 30px rgba(0,0,0,0.4);
    position: relative;
    overflow: hidden;
}

/* TOP GRADIENT LINE */
.card-box::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:4px;
    background:linear-gradient(90deg,var(--primary),var(--secondary),var(--accent));
}

/* HOVER */
.card-box:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.6);
}

/* ICON */
.icon {
    font-size: 40px;
    margin-bottom: 10px;
}

/* ICON COLORS OVERRIDE */
.text-primary{ color: var(--primary) !important; }
.text-success{ color: var(--accent) !important; }
.text-warning{ color: #f59e0b !important; }
.text-danger{ color: #ef4444 !important; }

/* BUTTON CUSTOM */
.btn-primary{
    background: var(--primary);
    border: none;
}
.btn-success{
    background: var(--accent);
    border: none;
}
.btn-warning{
    background: #f59e0b;
    border: none;
}
.btn-danger{
    background: #ef4444;
    border: none;
}

/* BUTTON HOVER */
.btn:hover{
    transform: scale(1.05);
    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
}

/* ===== WELCOME TEXT ===== */
.welcome {
    font-size: 28px;
    margin-bottom: 20px;
    color: var(--primary);
}

</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h3> Clinic</h3>

    <a href="user_dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="book_appointment.php"><i class="fa fa-calendar"></i> Book Appointment</a>
    <a href="my_appointments.php"><i class="fa fa-list"></i> My Appointments</a>
    <a href="user_prescriptions.php"><i class="fa fa-file-medical"></i> Prescriptions</a>
    <a href="user_payments.php"><i class="fa fa-credit-card"></i> Payments</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">

    <div class="welcome">
         Welcome, <b><?= $patient['name'] ?></b>
    </div>

    <!-- 2 CARDS PER ROW -->
    <div class="row g-4">

        <!-- CARD 1 -->
        <div class="col-md-6">
            <div class="card-box">
                <div class="icon text-primary">
                    <i class="fa fa-calendar-plus"></i>
                </div>
                <h5>Book Appointment</h5>
                <p>Schedule your visit easily</p>
                <a href="book_appointment.php" class="btn btn-primary btn-sm">Go</a>
            </div>
        </div>

        <!-- CARD 2 -->
        <div class="col-md-6">
            <div class="card-box">
                <div class="icon text-success">
                    <i class="fa fa-list"></i>
                </div>
                <h5>My Appointments</h5>
                <p>Check your appointments</p>
                <a href="my_appointments.php" class="btn btn-success btn-sm">View</a>
            </div>
        </div>

        <!-- CARD 3 -->
        <div class="col-md-6">
            <div class="card-box">
                <div class="icon text-warning">
                    <i class="fa fa-file-medical"></i>
                </div>
                <h5>Prescriptions</h5>
                <p>Your medical history</p>
                <a href="user_prescriptions.php" class="btn btn-warning btn-sm">Open</a>
            </div>
        </div>

        <!-- CARD 4 -->
        <div class="col-md-6">
            <div class="card-box">
                <div class="icon text-danger">
                    <i class="fa fa-credit-card"></i>
                </div>
                <h5>Payments</h5>
                <p>View payment details</p>
                <a href="user_payments.php" class="btn btn-danger btn-sm">Check</a>
            </div>
        </div>

    </div>

</div>

</body>
</html>
<?php
include "db.php";

$id = $_GET['id'];
$status = $_GET['status'];

$stmt = $conn->prepare("UPDATE appointments SET status=? WHERE id=?");
$stmt->bind_param("si", $status, $id);
$stmt->execute();

header("Location: appointments.php");
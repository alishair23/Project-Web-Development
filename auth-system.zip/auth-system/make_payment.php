<?php
session_start();
include "get_patient.php";

if(isset($_POST['submit'])){

    $amount = $_POST['amount'];

    if($amount <= 0){
        $error = "Invalid amount!";
    } else {

        $stmt = $conn->prepare("
            INSERT INTO payments (patient_id, amount, status)
            VALUES (?, ?, 'pending')
        ");
        $stmt->bind_param("id", $patient['id'], $amount);
        $stmt->execute();

        header("Location: user_payments.php");
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Make Payment</title>

<style>
body{
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    font-family:Poppins;
}

.card{
    width:350px;
    padding:30px;
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(20px);
    border-radius:15px;
    color:white;
}

input{
    width:100%;
    padding:10px;
    margin:10px 0;
    border:none;
    border-radius:8px;
}

button{
    width:100%;
    padding:12px;
    background:#22c55e;
    border:none;
    color:white;
    border-radius:8px;
}

.error{
    background:red;
    padding:10px;
    margin-bottom:10px;
}
</style>
</head>

<body>

<div class="card">
<h2>💳 Make Payment</h2>

<?php if(isset($error)): ?>
<div class="error"><?= $error ?></div>
<?php endif; ?>

<form method="POST" onsubmit="return validate()">

<input type="number" name="amount" id="amount" placeholder="Enter Amount" required>

<button name="submit">Proceed</button>

</form>

</div>

<script>
function validate(){
    let amount = document.getElementById("amount").value;

    if(amount <= 0){
        alert("Amount must be greater than 0");
        return false;
    }

    return true;
}
</script>

</body>
</html>
<?php
include "db.php";

$name = $_POST['patient_name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$doctor = $_POST['doctor'];
$date = $_POST['appointment_date'];
$time = $_POST['appointment_time'];
$message = $_POST['message'];

$stmt = $conn->prepare("INSERT INTO appointments 
(patient_name,email,phone,doctor,appointment_date,appointment_time,message) 
VALUES (?,?,?,?,?,?,?)");

$stmt->bind_param("sssssss", $name, $email, $phone, $doctor, $date, $time, $message);

if ($stmt->execute()) {
    echo "Appointment booked successfully!";
} else {
    echo "Error booking appointment";
}
?>
<?php
include "db.php";

$id = (int)$_GET['id'];

if(isset($_POST['submit'])){

    $notes = $_POST['notes'];
    $medicines = $_POST['medicines'];

    /* GET DOCTOR ID */
    $row = $conn->query("SELECT doctor_id, patient_id FROM appointments WHERE id=$id")->fetch_assoc();

    $stmt = $conn->prepare("
        INSERT INTO prescriptions (appointment_id, doctor_id, notes, medicines)
        VALUES (?,?,?,?)
    ");

    $stmt->bind_param("iiss", $id, $row['doctor_id'], $notes, $medicines);
    $stmt->execute();

    /* CREATE PAYMENT */
    $conn->query("
        INSERT INTO payments (patient_id, amount, status)
        VALUES ({$row['patient_id']}, 1500, 'pending')
    ");

    echo "Prescription saved & payment created!";
}
?>

<form method="POST">
<textarea name="notes" placeholder="Notes"></textarea><br>
<textarea name="medicines" placeholder="Medicines"></textarea><br>
<button name="submit">Save</button>
</form><?php
session_start();
include "db.php";

// ADMIN CHECK
if ($_SESSION['role'] != 'admin') {
    die("Access denied!");
}

// GET APPOINTMENT ID
if (!isset($_GET['id'])) {
    die("No appointment selected");
}

$appointment_id = (int) $_GET['id'];

// FETCH DATA (AUTO FILL)
$stmt = $conn->prepare("
SELECT 
    a.*, 
    p.name AS patient_name,
    d.doctor_name
FROM appointments a
JOIN patients p ON a.patient_id = p.id
JOIN doctors d ON a.doctor_id = d.doctor_id
WHERE a.id = ?
");

$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    die("Invalid appointment");
}

// INSERT PRESCRIPTION
if (isset($_POST['submit'])) {

    $notes = $_POST['notes'];
    $medicines = $_POST['medicines'];

    $stmt = $conn->prepare("
        INSERT INTO prescriptions (appointment_id, notes, medicines)
        VALUES (?, ?, ?)
    ");
    $stmt->bind_param("iss", $appointment_id, $notes, $medicines);
    $stmt->execute();

    header("Location: admin_prescriptions.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Prescription</title>

<style>
body{
    font-family:Arial;
    background:#0f172a;
    color:white;
    padding:30px;
}

.card{
    max-width:500px;
    margin:auto;
    background:#1e293b;
    padding:20px;
    border-radius:10px;
}

input,textarea{
    width:100%;
    padding:10px;
    margin:10px 0;
    border-radius:5px;
    border:none;
}

button{
    padding:10px;
    background:#3b82f6;
    border:none;
    color:white;
    border-radius:5px;
}

.info{
    background:#111827;
    padding:10px;
    border-radius:5px;
    margin-bottom:15px;
}
</style>
</head>

<body>

<div class="card">

<h2>💊 Add Prescription</h2>

<!-- AUTO FILLED INFO -->
<div class="info">
<b>Patient:</b> <?= $data['patient_name'] ?><br>
<b>Doctor:</b> <?= $data['doctor_name'] ?><br>
<b>Date:</b> <?= $data['appointment_date'] ?>
</div>

<form method="POST">

<textarea name="notes" placeholder="Doctor Notes" required></textarea>

<textarea name="medicines" placeholder="Medicines" required></textarea>

<button name="submit">Save Prescription</button>

</form>

</div>

</body>
</html>
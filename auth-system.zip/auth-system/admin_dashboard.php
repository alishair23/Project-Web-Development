<?php
session_start();
include "db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: index.html");
    exit();
}

/* ================= STATS ================= */
$totalPatients = $conn->query("SELECT COUNT(*) as total FROM patients")->fetch_assoc()['total'];
$totalAppointments = $conn->query("SELECT COUNT(*) as total FROM appointments")->fetch_assoc()['total'];
$totalPayments = $conn->query("SELECT SUM(amount) as total FROM payments WHERE status='paid'")->fetch_assoc()['total'] ?? 0;

/* ================= RECENT APPOINTMENTS ================= */
$appointments = $conn->query("
SELECT 
    a.*, 
    p.name,
    d.doctor_name
FROM appointments a
LEFT JOIN patients p ON a.patient_id = p.id
LEFT JOIN doctors d ON a.doctor_id = d.doctor_id
ORDER BY a.appointment_date DESC 
LIMIT 5
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
<style>
:root{
    --primary:#3B82F6;
    --secondary:#06B6D4;
    --accent:#10B981;
}

/* RESET */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

/* BODY */
body{
    font-family:'Poppins', sans-serif;
    background:linear-gradient(135deg, #0f172a, #1e293b);
    display:flex;
    color:#e2e8f0;
}

/* ================= SIDEBAR ================= */
.sidebar{
    width:250px;
    color:white;
    height:100vh;
    padding:20px;
}

.sidebar h2{
    margin-bottom:25px;
    font-weight:600;
}

/* FIXED HERE */
.sidebar a{
    display:block;
    padding:12px;
    margin:8px 0;
    background:rgba(255,255,255,0.05);
    color:#e2e8f0;
    text-decoration:none;
    border-radius:8px;
    transition:.3s;
}

.sidebar a:hover{
    background:linear-gradient(90deg,var(--secondary),var(--primary));
    transform:translateX(5px);
}

/* ================= MAIN ================= */
.main{
    flex:1;
    padding:25px;
}

/* TOPBAR */
.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;

    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(12px);

    padding:15px 20px;
    border-radius:12px;

    box-shadow:0 5px 15px rgba(0,0,0,0.3);
}

.topbar h1{
    color:white;
}

/* LOGOUT */
.logout{
    background:linear-gradient(90deg,#ef4444,#dc2626);
    color:white;
    padding:8px 15px;
    border-radius:8px;
    text-decoration:none;
}

.logout:hover{
    transform:scale(1.05);
}

/* ================= CARDS ================= */
.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
    margin-top:25px;
}

.card{
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(12px);

    padding:22px;
    border-radius:16px;

    box-shadow:0 10px 25px rgba(0,0,0,0.3);
    position:relative;

    transition:.3s;
}

/* gradient top */
.card::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:5px;
}

.card h3{
    font-size:14px;
    color:#94a3b8;
}

.card p{
    font-size:30px;
    font-weight:bold;
    margin-top:10px;
    color:white;
}

.card:hover{
    transform:translateY(-6px);
}

/* ================= QUICK LINKS ================= */
.quick-links{
    margin-top:30px;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:15px;
}

.quick-links a{
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(12px);

    padding:15px;
    border-radius:12px;

    text-decoration:none;
    color:#e2e8f0;

    box-shadow:0 5px 15px rgba(0,0,0,0.3);
    transition:.3s;
    text-align:center;
}

.quick-links a:hover{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
}

/* ================= TABLE ================= */
.table-box{
    margin-top:30px;

    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(12px);

    padding:20px;
    border-radius:16px;

    box-shadow:0 10px 25px rgba(0,0,0,0.3);
}

table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:12px;
}

th{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
    color:white;
}

tr{
    transition:.2s;
}

tr:hover{
    background:rgba(59,130,246,0.15);
}
h2{
    color:Green;
    font-weight:10%;
}
</style>
</head>

<body>
<div class="sidebar">
    <h2>+MediCare</h2>

    <a href="admin_dashboard.php">Dashboard</a>
    <a href="patients.php">Patients</a>
    <a href="appointments.php">Appointments</a>
    <a href="doctors.php">Doctors</a>
    <a href="admin_payments.php">Payments</a>
    <a href="admin_prescriptions.php">Prescriptions</a>
    
    <a href="User Management.php">User Management</a>
    <a href="logout.php">Logout</a>
</div>


<div class="main">

<!-- TOPBAR -->
<div class="topbar">
    <h1>Admin Dashboard</h1>
    <a href="logout.php" class="logout">Logout</a>
</div>

<!-- CARDS -->
<div class="cards">

<div class="card">
    <div class="card-top">
        <h3>Total Patients</h3>
    </div>
    <p><?= $totalPatients ?></p>
</div>

<div class="card">
    <div class="card-top">
        <h3>Appointments</h3>
    </div>
    <p><?= $totalAppointments ?></p>
</div>

<div class="card">
    <div class="card-top">
        <h3>Total Revenue</h3>
    </div>
    <p>Rs <?= number_format($totalPayments) ?></p>
</div>

</div>

<div class="quick-links">
    <a href="patients.php">Manage Patients</a>
    <a href="appointments.php">Manage Appointments</a>
    <a href="doctors.php">Manage Doctors</a>
    <a href="admin_payments.php">Manage Payments</a>
</div>

<div class="table-box">
<h3>Recent Appointments</h3>

<table>
<tr>
<th>Patient</th>
<th>Doctor</th>
<th>Date</th>
<th>Status</th>
</tr>



<?php while($row = $appointments->fetch_assoc()): ?>
<tr>
<td><?= htmlspecialchars($row['name']) ?></td>
<td><?= $row['doctor_name'] ?? 'N/A' ?></td>
<td><?= $row['appointment_date'] ?></td>
<td><?= ucfirst($row['status']) ?></td>
</tr>
<?php endwhile; ?>

</table>
</div>

</div>

</body>
</html>
<?php
include "db.php";

$id = (int)$_GET['id'];

$stmt = $conn->prepare("DELETE FROM patients WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();

header("Location: patients.php");
exit();
?>